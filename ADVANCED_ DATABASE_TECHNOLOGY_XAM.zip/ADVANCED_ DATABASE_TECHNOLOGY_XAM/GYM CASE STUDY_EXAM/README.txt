
UNIVERSITY OF RWANDA
MUKANDAYISENGA MARIE CHANTAK
REG NO:224019567
FINAL EXAM OF ADVENCED DATABASE TECHNOLOGY


README.txt – Distributed Attendance Fragmentation Setup

1. Objective:
   - Horizontally fragment the Attendance table across two nodes (Node_A and Node_B)
   - Use a deterministic rule (RANGE on MemberID) to distribute data
   - Enable cross-node access using PostgreSQL FDW
   - Integrate horizontally fragmented attendance data from Node_A and Node_B
   - Use PostgreSQL FDW to access remote fragments
   - Create unified views and validate distributed joins and aggregations
   - Demonstrate distributed transactions across Node_A and Node_B using FDW
   - Validate rollback, prepare/commit, and lock detection mechanisms
   - Enforce data integrity on Subscription and Payment tables
   - Validate business rules using NOT NULL and CHECK constraints
   - Demonstrate passing and failing INSERTs with rollback control
   - Maintain ≤10 committed rows for academic budget
- Enforce business rules on Subscription and Payment tables
- Log changes using audit tables and triggers
- Model multi-level member hierarchy using recursive relationships
- Maintain ≤10 committed rows across all operations


2. Fragmentation Rule:
   - Attendance_A stores MemberID 1–5 (Node_A)
   - Attendance_B stores MemberID 6–10 (Node_B)

3. Table Definitions:

-- On Node_A
CREATE TABLE Attendance_A (
    AttendanceID SERIAL PRIMARY KEY,
    MemberID INT,
    CheckInTime TIMESTAMP,
    CheckOutTime TIMESTAMP,
    Date DATE
);

-- On Node_B
CREATE TABLE Attendance_B (
    AttendanceID SERIAL PRIMARY KEY,
    MemberID INT,
    CheckInTime TIMESTAMP,
    CheckOutTime TIMESTAMP,
    Date DATE
);

4. Sample Data:

-- Node_A
INSERT INTO Attendance_A (MemberID, CheckInTime, CheckOutTime, Date)
VALUES
(1, now() - interval '2h', now() - interval '1h', current_date),
(2, now() - interval '3h', now() - interval '2h', current_date),
(3, now() - interval '4h', now() - interval '3h', current_date),
(4, now() - interval '5h', now() - interval '4h', current_date),
(5, now() - interval '6h', now() - interval '5h', current_date);

-- Node_B
INSERT INTO Attendance_B (MemberID, CheckInTime, CheckOutTime, Date)
VALUES
(6, now() - interval '2h', now() - interval '1h', current_date),
(7, now() - interval '3h', now() - interval '2h', current_date),
(8, now() - interval '4h', now() - interval '3h', current_date),
(9, now() - interval '5h', now() - interval '4h', current_date),
(10, now() - interval '6h', now() - interval '5h', current_date);

5. Foreign Data Wrapper Setup (on Node_A):

-- Enable FDW
CREATE EXTENSION IF NOT EXISTS postgres_fdw;

-- Declare remote server
CREATE SERVER node_b_server
FOREIGN DATA WRAPPER postgres_fdw
OPTIONS (host 'localhost', dbname 'node_b_db', port '5432');

-- Map user credentials
CREATE USER MAPPING FOR CURRENT_USER
SERVER node_b_server
OPTIONS (user 'gym_user1', password 'gym_pass');

6. User and Database Setup (on Node_B):

-- Create user and database
CREATE USER gym_user WITH PASSWORD 'gym_pass';
CREATE DATABASE node_b_db;
GRANT CONNECT ON DATABASE node_b_db TO gym_user;

7. Notes:
- This setup enables distributed query execution across nodes
- Attendance_B can be accessed from Node_A via FDW
- Reuse this data for joins, triggers, and reporting tasks

8. Distributed Attendance Integration and Validation



9. Foreign Table Import (Node_A):
   - Imported Attendance_B from Node_B using FDW
   - Defined foreign table manually for Attendance_B

CREATE FOREIGN TABLE Attendance_B (
    AttendanceID INT,
    MemberID INT,
    CheckInTime TIMESTAMP,
    CheckOutTime TIMESTAMP,
    Date DATE
)
SERVER node_b_server
OPTIONS (table_name 'Attendance_B');

10. Unified View:
   - Combined Attendance_A and Attendance_B using UNION ALL

CREATE VIEW Attendance_ALL AS
SELECT * FROM Attendance_A
UNION ALL
SELECT * FROM Attendance_B;

11. Validation Queries:
   - Total row count:
     SELECT COUNT(*) FROM Attendance_ALL;

   - Checksum validation:
     SELECT SUM(MOD(MemberID, 97)) FROM Attendance_ALL;
     SELECT SUM(MOD(MemberID, 97)) FROM Attendance_A;
     SELECT SUM(MOD(MemberID, 97)) FROM Attendance_B;

   - Fragment counts:
     SELECT COUNT(*) AS count_a FROM Attendance_A;
     SELECT COUNT(*) AS count_b FROM Attendance_B;
     SELECT COUNT(*) AS count_all FROM Attendance_ALL;

12. FDW Setup:
   - Enabled postgres_fdw on Node_A
   - Created server link to Node_B

CREATE SERVER proj_link
FOREIGN DATA WRAPPER postgres_fdw
OPTIONS (
    host '192.168.43.182',
    dbname 'node_b_db',
    port '5432'
);

   - Created user mapping:

CREATE USER MAPPING FOR CURRENT_USER
SERVER proj_link
OPTIONS (
    user 'gym_user',
    password 'gym_pass'
);

13. Distributed Joins:
   - Join Attendance_A and Attendance_B on MemberID
   - Join Attendance_A with Member table for enriched reporting

SELECT
    A.AttendanceID AS LocalID,
    B.AttendanceID AS RemoteID,
    A.MemberID,
    A.CheckInTime AS LocalCheckIn,
    B.CheckInTime AS RemoteCheckIn
FROM Attendance_A A
JOIN Attendance_B B ON A.MemberID = B.MemberID
LIMIT 5;

SELECT
    A.AttendanceID,
    A.Memberid,
    M.fullname,
    A.CheckInTime,
    A.Date
FROM Attendance_A A
JOIN Member M ON A.Memberid = M.Memberid
WHERE A.Date >= '2025-01-10'
LIMIT 10;

14. Aggregation Queries:
   - Group by Date:
     SELECT Date, COUNT(*) AS TotalSessions FROM Attendance_ALL GROUP BY Date ORDER BY Date LIMIT 10;

   - Group by MemberID:
     SELECT MemberID, COUNT(*) AS SessionCount FROM Attendance_ALL GROUP BY MemberID ORDER BY SessionCount DESC LIMIT 10;

15. Parallel Execution Tuning:
   - Enabled parallelism for performance benchmarking

SET max_parallel_workers_per_gather = 8;
SET parallel_setup_cost = 0;
SET parallel_tuple_cost = 0;

EXPLAIN ANALYZE
SELECT Date, COUNT(*) AS TotalSessions
FROM Attendance_ALL
GROUP BY Date
ORDER BY Date
LIMIT 10;

16. Notes:
   - Attendance_ALL view supports unified reporting across nodes
   - FDW enables seamless cross-node queries
   - Parallel tuning improves aggregation performance


 Distributed Transaction and Locking Demo


17. Aggregation Benchmark:
EXPLAIN ANALYZE
SELECT Date, COUNT(*) FROM Attendance_ALL GROUP BY Date ORDER BY Date LIMIT 10;

18. Transaction Rollback Demo:
BEGIN;
-- Local insert
INSERT INTO Attendance_A VALUES (1001, 301, '2025-10-28 08:30', '2025-10-28 09:30', '2025-10-28');
-- Remote insert via FDW
INSERT INTO Payment VALUES (7001, 4001, 15000.00, '2025-10-28', 'Mobile Money');
ROLLBACK;

19. Invalid Remote Insert:
BEGIN;
INSERT INTO Attendance_A VALUES (1002, 302, '2025-10-29 08:00', '2025-10-29 09:00', '2025-10-29');
-- Remote insert with NULL and invalid type
INSERT INTO Payment VALUES (7002, NULL, 'invalid', '2025-10-29');
ROLLBACK;

20. Two-Phase Commit:
BEGIN;
-- Insert operations
PREPARE TRANSACTION 'txn_001';
SELECT * FROM pg_prepared_xacts;
COMMIT PREPARED 'txn_001';

21. Successful Distributed Commit:
BEGIN;
INSERT INTO Attendance_A VALUES (1003, 303, '2025-10-30 08:00', '2025-10-30 09:00', '2025-10-30');
INSERT INTO Payment VALUES (7003, 4003, 12000.00, '2025-10-30', 'Bank Transfer');
COMMIT;

22. Locking and Blocking Detection:
-- Update local and remote rows
BEGIN;
UPDATE Subscription SET status = 'Suspended' WHERE subscriptionId = 4003;
UPDATE Payment SET method = 'Suspended' WHERE paymentId = 7003;

-- On Node_B via FDW
UPDATE Payment SET method = 'Credit Card' WHERE paymentId = 7003;

-- View locks
SELECT * FROM pg_locks;

-- Detect blocked sessions
SELECT blocked_locks.pid AS blocked_pid, blocking_locks.pid AS blocking_pid
FROM pg_locks blocked_locks
JOIN pg_locks blocking_locks ON blocking_locks.transactionid = blocked_locks.transactionid
WHERE NOT blocked_locks.granted;

23. Notes:
- FDW supports remote inserts and updates
- PostgreSQL aborts transactions on constraint or connection failure
- Lock views help diagnose concurrency issues


 Declarative Rules Hardening and Transaction Validation


24. Lock Management and Session Coordination:
-- View active sessions
SELECT pid, usename, query, state, wait_event_type, wait_event
FROM pg_stat_activity WHERE state != 'idle';

-- Release lock in Session 1
BEGIN;
UPDATE Payment SET method = 'Suspended' WHERE paymentId = 7003;
COMMIT;

-- Session 2 completes via FDW
UPDATE Payment SET method = 'Credit Card' WHERE paymentId = 7003;

-- Verify result
SELECT paymentId, method FROM Payment WHERE paymentId = 7003;

25. Constraint Enforcement – Subscription Table:
-- Enforce NOT NULL
ALTER TABLE Subscription
  ALTER COLUMN memberId SET NOT NULL,
  ALTER COLUMN startDate SET NOT NULL,
  ALTER COLUMN endDate SET NOT NULL,
  ALTER COLUMN status SET NOT NULL,
  ALTER COLUMN plantype SET NOT NULL;

-- Enforce valid status
ALTER TABLE Subscription
ADD CONSTRAINT subscription_status_check
CHECK (status IN ('Active', 'Suspended', 'Expired'));

-- Enforce date logic
ALTER TABLE Subscription
ADD CONSTRAINT chk_subscription_dates
CHECK (startDate < endDate);

26. Constraint Enforcement – Payment Table:
-- Enforce NOT NULL
ALTER TABLE Payment
  ALTER COLUMN subscriptionId SET NOT NULL,
  ALTER COLUMN amount SET NOT NULL,
  ALTER COLUMN paymentDate SET NOT NULL,
  ALTER COLUMN method SET NOT NULL;

-- Enforce positive amount
ALTER TABLE Payment
ADD CONSTRAINT chk_payment_amount CHECK (amount > 0);

-- Enforce valid method
ALTER TABLE Payment
ADD CONSTRAINT payment_method_check
CHECK (method IN ('Mobile Money', 'Bank Transfer', 'Cash', 'Credit Card'));

-- Verify constraints
SELECT conname, contype, convalidated
FROM pg_constraint
WHERE conrelid = 'subscription'::regclass OR conrelid = 'payment'::regclass;

27. Passing INSERTs – Subscription:
-- Valid subscriptions
INSERT INTO Subscription VALUES (4004, 304, '2025-10-15', '2025-11-15', 'Monthly', 'Active');
INSERT INTO Subscription VALUES (4010, 310, '2025-11-01', '2025-12-01', 'Monthly', 'Active');
INSERT INTO Subscription VALUES (4011, 311, '2025-11-01', '2025-12-01', 'Monthly', 'Suspended');

28. Passing INSERTs – Payment:
-- Valid payments
INSERT INTO Payment VALUES (7004, 4004, 10000.00, '2025-11-02', 'Mobile Money');
INSERT INTO Payment VALUES (7005, 4005, 8000.00, '2025-11-03', 'Bank Transfer');

29. Failing INSERTs – Wrapped in ROLLBACK:
BEGIN;
-- Invalid status
INSERT INTO Subscription VALUES (4006, 306, '2025-11-01', '2025-12-01', 'Monthly', 'Paused');

-- Invalid date logic
INSERT INTO Subscription VALUES (4007, 307, '2025-12-01', '2025-11-01', 'Monthly', 'Active');

-- Negative amount
INSERT INTO Payment VALUES (7006, 4004, -5000.00, '2025-11-04', 'Cash');

-- Invalid method
INSERT INTO Payment VALUES (7007, 4005, 9000.00, '2025-11-05', 'Bitcoin');
ROLLBACK;

30. Error Handling Block (Optional):
DO $$
BEGIN
  -- INSERT logic here
EXCEPTION
  WHEN others THEN
    RAISE NOTICE 'Insert failed due to constraint violation.';
END;
$$;

31. Notes:
- All failing inserts were rolled back to preserve ≤10 committed row budget
- Constraints ensure clean, rule-compliant data for trainer sessions and revenue tracking
- Lock coordination and FDW updates validated cross-node consistency


 Declarative Integrity, Audit Logging, and Recursive Hierarchy


32. Constraint Enforcement:
- Subscription: NOT NULL on memberId, startDate, endDate, status, plantype
- CHECK constraints:
  - status IN ('Active', 'Suspended', 'Expired')
  - startDate < endDate
- Payment: NOT NULL on subscriptionId, amount, paymentDate, method
- CHECK constraints:
  - amount > 0
  - method IN ('Mobile Money', 'Bank Transfer', 'Cash', 'Credit Card')

33. Failing INSERTs (Handled with Error Logging):
DO $$
BEGIN
  -- Invalid status
  INSERT INTO Subscription VALUES (4012, 312, '2025-11-01', '2025-12-01', 'Monthly', 'Paused');
EXCEPTION WHEN others THEN
  RAISE NOTICE 'Subscription INSERT failed: %', SQLERRM;
END;
$$;

DO $$
BEGIN
  -- Negative amount
  INSERT INTO Payment VALUES (7008, 4004, -5000.00, '2025-11-04', 'Cash');
EXCEPTION WHEN others THEN
  RAISE NOTICE 'Payment INSERT failed: %', SQLERRM;
END;
$$;

34. Audit Logging:
- Table: Subscription_AUDIT (bef_total, aft_total, changed_at, key_col)
- Manual entries:
  - INSERT 4006
  - DELETE 4005
  - AFTER Payment Trigger

SELECT * FROM Subscription_AUDIT ORDER BY changed_at DESC;


35. Trigger-Based Recalculation:
- Added column: Subscription.total_paid
- Trigger: trg_recompute_totals (AFTER INSERT/UPDATE/DELETE on Payment)
- Function: recompute_subscription_totals() updates total_paid per subscription

36. CHILD Table and Mixed DML:
CREATE TABLE Child (
  childId INTEGER PRIMARY KEY,
  name VARCHAR(50) NOT NULL,
  age INTEGER CHECK (age > 0),
  subscriptionId INTEGER REFERENCES Subscription(subscriptionId)
);

-- Valid DML:
INSERT INTO Child VALUES (105, 'Aline', 8, 4004);
INSERT INTO Child VALUES (103, 'Eric', 10, 4005);
UPDATE Child SET age = age + 1 WHERE childId = 104;
DELETE FROM Child WHERE childId = 103;

-- Failing DML (rolled back):
BEGIN;
INSERT INTO Child VALUES (106, NULL, 8, 4005); -- NULL name
UPDATE Child SET age = 13 WHERE childId = 999; -- non-existent
ROLLBACK;

37. Recursive Hierarchy Modeling:
- Table: HIER(parent_id, child_id) referencing Member(memberId)
- Inserted 8 Member rows with planType and status
- Inserted 6 HIER rows forming 3-level hierarchy:
  - Level 1: Parent → Child
  - Level 2: Child → Grandchild

SELECT * FROM HIER;
SELECT * FROM Member;

38. Attendance Table Extension:
ALTER TABLE Attendance
  ADD COLUMN member_id INTEGER REFERENCES Member(memberId),
  ADD COLUMN attended_on TIMESTAMP;

39. Row Budget Summary:
- All failing DML wrapped in ROLLBACK
- Net committed rows ≤10 across Subscription, Payment, Child, Member, HIER


 Recursive Rollups, Semantic Inference, and Business Rule Enforcement

40. Recursive Roll-Up:
- Used WITH RECURSIVE to trace (child_id, root_id, depth) from HIER
- Joined to Attendance to compute total attendance per root
- Returned ≤10 rollup rows

41. Semantic Inference:
- TRIPLE table modeled domain facts (e.g., isA, hasPlan)
- Recursive query inferred transitive isA relationships
- Returned labeled facts for up to 10 entities

42. Business Rule Enforcement:
- BUSINESS_LIMITS table defined MAX_SESSIONS_PER_DAY
- fn_should_alert() checks session count per member
- Trigger on Payment blocks inserts if rule is violated

43. DML Validation:
- 2 passing Payment inserts (members 201, 202) committed
- 2 failing inserts (members 203, 204) rolled back
- Total committed rows remain within ≤10 budget
44. Audit and Hierarchy:
- Member and HIER tables modeled 3-level sponsorship
- Attendance and Session tables linked to member activity
- TRIPLE facts and recursive logic enriched semantic structure

